// page/details/details.js
Page({
  data: {

    goods: {

      
    },
    num: 1,
    totalNum: 0,
    hasCarts: false,
    curIndex: 0,
    show: false,
    scaleCart: false
  }
})